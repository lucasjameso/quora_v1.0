import React, { useState } from 'react';
import { ArrowLeft, BookOpen, MessageSquare, Calendar, Shield, Sparkles } from 'lucide-react';

interface HowItWorksProps {
  onReturn: () => void;
}

interface FeatureDetail {
  title: string;
  description: string;
  benefits: string[];
  workflow: {
    step: string;
    description: string;
  }[];
  integrations: string[];
  examples: {
    scenario: string;
    solution: string;
  }[];
}

const featureDetails: Record<string, FeatureDetail> = {
  insights: {
    title: "Compliance Insights",
    description: "Our Compliance Insights feature delivers expert-curated knowledge and analysis of regulatory requirements specific to facade access and exterior building maintenance.",
    benefits: [
      "Stay updated with the latest regulatory changes and interpretations",
      "Access expert analysis from industry professionals",
      "Receive monthly focused training sessions",
      "Build a comprehensive knowledge base for your team"
    ],
    workflow: [
      {
        step: "Monthly Sessions",
        description: "Join live sessions with John Ho from Engineering for deep dives into specific regulations"
      },
      {
        step: "Knowledge Repository",
        description: "Access recorded sessions and supplementary materials in our organized library"
      },
      {
        step: "Team Discussion",
        description: "Participate in Q&A sessions and collaborative discussions"
      }
    ],
    integrations: [
      "Calendar integration for session reminders",
      "Document management system for session materials",
      "Team collaboration tools for discussion threads"
    ],
    examples: [
      {
        scenario: "New OSHA Regulation Update",
        solution: "Access expert analysis of changes and implementation requirements through monthly sessions"
      },
      {
        scenario: "Project-Specific Compliance",
        solution: "Review past sessions and documentation relevant to your current project needs"
      }
    ]
  },
  regulations: {
    title: "Regulations Library",
    description: "A comprehensive database of regulatory documents, organized and searchable by region, type, and application.",
    benefits: [
      "Quick access to relevant regulations",
      "Region-specific compliance documentation",
      "Regular updates with new requirements",
      "Advanced search and filtering capabilities"
    ],
    workflow: [
      {
        step: "Search",
        description: "Use powerful search tools to find specific regulations or requirements"
      },
      {
        step: "Filter",
        description: "Narrow results by region, date, or regulation type"
      },
      {
        step: "Save",
        description: "Bookmark frequently used documents for quick access"
      }
    ],
    integrations: [
      "Document management systems",
      "Project planning tools",
      "Compliance tracking software"
    ],
    examples: [
      {
        scenario: "Multi-State Project Planning",
        solution: "Access and compare regulations across different jurisdictions"
      },
      {
        scenario: "Safety Requirement Verification",
        solution: "Quickly locate specific safety standards for compliance checks"
      }
    ]
  },
  standards: {
    title: "Standards Library",
    description: "Access industry standards and best practices for facade access and building maintenance systems.",
    benefits: [
      "Comprehensive collection of industry standards",
      "Best practices documentation",
      "Regular updates with new standards",
      "Cross-reference capabilities"
    ],
    workflow: [
      {
        step: "Browse Categories",
        description: "Navigate through organized sections of standards and practices"
      },
      {
        step: "Compare Standards",
        description: "View and compare different standards side by side"
      },
      {
        step: "Implementation Guide",
        description: "Access practical guides for standard implementation"
      }
    ],
    integrations: [
      "Project management tools",
      "Quality assurance systems",
      "Training platforms"
    ],
    examples: [
      {
        scenario: "New Installation Design",
        solution: "Reference relevant standards for design specifications"
      },
      {
        scenario: "Maintenance Protocol Development",
        solution: "Create procedures based on industry best practices"
      }
    ]
  },
  gpt: {
    title: "ComplianceGPT",
    description: "AI-powered assistance for instant access to compliance information and interpretations.",
    benefits: [
      "Instant answers to compliance questions",
      "Context-aware recommendations",
      "Document analysis capabilities",
      "Natural language interaction"
    ],
    workflow: [
      {
        step: "Ask Questions",
        description: "Use natural language to query compliance requirements"
      },
      {
        step: "Upload Documents",
        description: "Get analysis of compliance documents and requirements"
      },
      {
        step: "Receive Guidance",
        description: "Get contextual recommendations and related insights"
      }
    ],
    integrations: [
      "Document processing systems",
      "Project management tools",
      "Communication platforms"
    ],
    examples: [
      {
        scenario: "Regulation Interpretation",
        solution: "Get instant clarification on specific requirements"
      },
      {
        scenario: "Document Review",
        solution: "Upload documents for automated compliance analysis"
      }
    ]
  },
  future: {
    title: "Future Development",
    description: "Upcoming features and enhancements to improve your compliance management experience.",
    benefits: [
      "Advanced search capabilities",
      "Real-time updates",
      "Enhanced collaboration tools",
      "Automated compliance tracking"
    ],
    workflow: [
      {
        step: "Feature Preview",
        description: "Early access to upcoming features"
      },
      {
        step: "Feedback Loop",
        description: "Provide input on feature development"
      },
      {
        step: "Implementation",
        description: "Smooth transition to new capabilities"
      }
    ],
    integrations: [
      "Existing compliance systems",
      "Team collaboration tools",
      "Project management platforms"
    ],
    examples: [
      {
        scenario: "Advanced Analytics",
        solution: "Track compliance metrics and trends over time"
      },
      {
        scenario: "Automated Updates",
        solution: "Receive real-time notifications of regulatory changes"
      }
    ]
  }
};

export function HowItWorks({ onReturn }: HowItWorksProps) {
  const [activeSection, setActiveSection] = useState<keyof typeof featureDetails>('insights');
  const details = featureDetails[activeSection];

  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#F4F5F1]">
      {/* Header with Return Button */}
      <div className="sticky top-0 z-50 bg-[#1A1A1A] border-b border-[#333333]/30">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <button
            onClick={onReturn}
            className="flex items-center gap-2 text-[#F46F25] hover:text-[#FF8544] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Return to Home</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-6xl mx-auto px-6 pt-4">
          <div className="flex items-center gap-4 overflow-x-auto pb-4 scrollbar-thin">
            <button
              onClick={() => setActiveSection('insights')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                activeSection === 'insights'
                  ? 'bg-[#F46F25] text-white'
                  : 'text-[#7F7F7F] hover:text-[#F4F5F1] hover:bg-[#333333]/30'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Compliance Insights</span>
            </button>
            <button
              onClick={() => setActiveSection('regulations')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                activeSection === 'regulations'
                  ? 'bg-[#F46F25] text-white'
                  : 'text-[#7F7F7F] hover:text-[#F4F5F1] hover:bg-[#333333]/30'
              }`}
            >
              <Shield className="w-4 h-4" />
              <span>Regulations Library</span>
            </button>
            <button
              onClick={() => setActiveSection('standards')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                activeSection === 'standards'
                  ? 'bg-[#F46F25] text-white'
                  : 'text-[#7F7F7F] hover:text-[#F4F5F1] hover:bg-[#333333]/30'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>Standards Library</span>
            </button>
            <button
              onClick={() => setActiveSection('gpt')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                activeSection === 'gpt'
                  ? 'bg-[#F46F25] text-white'
                  : 'text-[#7F7F7F] hover:text-[#F4F5F1] hover:bg-[#333333]/30'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>ComplianceGPT</span>
            </button>
            <button
              onClick={() => setActiveSection('future')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg whitespace-nowrap transition-colors ${
                activeSection === 'future'
                  ? 'bg-[#F46F25] text-white'
                  : 'text-[#7F7F7F] hover:text-[#F4F5F1] hover:bg-[#333333]/30'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Future Development</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="space-y-12">
          {/* Header Section */}
          <div className="space-y-4">
            <h1 className="text-4xl font-bold text-[#F4F5F1]">{details.title}</h1>
          </div>

          {/* Content */}
          <div className="prose prose-invert max-w-none space-y-8">
            <div className="bg-[#333333]/20 border border-[#333333]/30 rounded-xl p-8">
              <h3 className="text-xl font-semibold mb-4">{details.description}</h3>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-medium mb-3">Key Benefits</h4>
                  <ul className="space-y-2">
                    {details.benefits.map((benefit, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="mt-1.5">
                          <div className="w-1.5 h-1.5 rounded-full bg-[#F46F25]" />
                        </div>
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-lg font-medium mb-3">Workflow</h4>
                  <div className="space-y-4">
                    {details.workflow.map((step, index) => (
                      <div key={index} className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-[#F46F25]/10 flex items-center justify-center">
                          <span className="text-[#F46F25] font-medium">{index + 1}</span>
                        </div>
                        <div>
                          <h5 className="font-medium mb-1">{step.step}</h5>
                          <p className="text-[#E1E1E1]">{step.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium mb-3">Integrations</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {details.integrations.map((integration, index) => (
                      <div key={index} className="flex items-center gap-2 p-3 rounded-lg bg-[#333333]/30">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#F46F25]" />
                        <span>{integration}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-medium mb-3">Real-World Examples</h4>
                  <div className="space-y-4">
                    {details.examples.map((example, index) => (
                      <div key={index} className="p-4 rounded-lg bg-[#333333]/30">
                        <h5 className="font-medium mb-2">Scenario: {example.scenario}</h5>
                        <p className="text-[#E1E1E1]">Solution: {example.solution}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}