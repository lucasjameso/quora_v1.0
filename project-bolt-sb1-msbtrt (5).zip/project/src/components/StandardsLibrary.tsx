import React from 'react';
import { ArrowLeft, Calendar, BookOpen, Shield, FileCheck } from 'lucide-react';

interface StandardsLibraryProps {
  onReturn: () => void;
}

export function StandardsLibrary({ onReturn }: StandardsLibraryProps) {
  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#F4F5F1]">
      {/* Header with Return Button */}
      <div className="border-b border-[#333333]/30">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <button
            onClick={onReturn}
            className="flex items-center gap-2 text-[#F46F25] hover:text-[#FF8544] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Return to Home</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="space-y-12">
          {/* Header Section */}
          <div className="space-y-4">
            <h1 className="text-4xl font-bold text-[#F4F5F1]">Standards Library</h1>
            <div className="flex items-center gap-2 text-[#F46F25]">
              <Calendar className="w-5 h-5" />
              <span className="text-lg">Coming Soon</span>
            </div>
          </div>

          {/* Main Description */}
          <div className="prose prose-invert max-w-none">
            <p className="text-xl text-[#E1E1E1] leading-relaxed">
              Standards Library for Facade Access and Construction Compliance
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-xl bg-[#333333]/20 border border-[#333333]/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-[#F46F25]/10">
                  <BookOpen className="w-5 h-5 text-[#F46F25]" />
                </div>
                <h3 className="text-lg font-semibold">Curated Collection</h3>
              </div>
              <p className="text-[#E1E1E1] leading-relaxed">
                Access authoritative standards for project planning and safety compliance in facade access.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#333333]/20 border border-[#333333]/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-[#F46F25]/10">
                  <Shield className="w-5 h-5 text-[#F46F25]" />
                </div>
                <h3 className="text-lg font-semibold">Best Practices</h3>
              </div>
              <p className="text-[#E1E1E1] leading-relaxed">
                Industry-leading standards and compliance benchmarks for exterior building maintenance.
              </p>
            </div>
          </div>

          {/* Launch Date */}
          <div className="bg-[#333333]/20 border border-[#333333]/30 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[#F46F25]/10">
                <FileCheck className="w-5 h-5 text-[#F46F25]" />
              </div>
              <h3 className="text-lg font-semibold">Expected Launch</h3>
            </div>
            <p className="text-[#E1E1E1] leading-relaxed">
              December 25, 2024
            </p>
          </div>

          {/* Vision Section */}
          <div className="border-t border-[#333333]/30 pt-8">
            <h2 className="text-2xl font-bold mb-4">Vision for this Page</h2>
            <p className="text-[#E1E1E1] leading-relaxed">
              Deliver a structured repository of industry standards, empowering our team with reliable 
              guidance for maintaining excellence in safety and regulatory compliance.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}