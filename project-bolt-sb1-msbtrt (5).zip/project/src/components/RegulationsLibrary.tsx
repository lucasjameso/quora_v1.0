import React from 'react';
import { ArrowLeft, Calendar, Search, BookOpen, Globe } from 'lucide-react';

interface RegulationsLibraryProps {
  onReturn: () => void;
}

export function RegulationsLibrary({ onReturn }: RegulationsLibraryProps) {
  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#F4F5F1]">
      {/* Header with Return Button */}
      <div className="border-b border-[#333333]/30">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <button
            onClick={onReturn}
            className="flex items-center gap-2 text-[#F46F25] hover:text-[#FF8544] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Return to Home</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="space-y-12">
          {/* Header Section */}
          <div className="space-y-4">
            <h1 className="text-4xl font-bold text-[#F4F5F1]">Regulations Library</h1>
            <div className="flex items-center gap-2 text-[#F46F25]">
              <Calendar className="w-5 h-5" />
              <span className="text-lg">Coming Soon</span>
            </div>
          </div>

          {/* Main Description */}
          <div className="prose prose-invert max-w-none">
            <p className="text-xl text-[#E1E1E1] leading-relaxed">
              Comprehensive Regulations Library for Facade Access Solutions
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-xl bg-[#333333]/20 border border-[#333333]/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-[#F46F25]/10">
                  <Search className="w-5 h-5 text-[#F46F25]" />
                </div>
                <h3 className="text-lg font-semibold">Smart Search</h3>
              </div>
              <p className="text-[#E1E1E1] leading-relaxed">
                Easily search and filter documents to find precisely what you need for project planning and execution.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#333333]/20 border border-[#333333]/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-[#F46F25]/10">
                  <Globe className="w-5 h-5 text-[#F46F25]" />
                </div>
                <h3 className="text-lg font-semibold">Region-Specific</h3>
              </div>
              <p className="text-[#E1E1E1] leading-relaxed">
                Access region-specific laws, codes, and compliance documentation tailored to your needs.
              </p>
            </div>
          </div>

          {/* Launch Date */}
          <div className="bg-[#333333]/20 border border-[#333333]/30 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[#F46F25]/10">
                <Calendar className="w-5 h-5 text-[#F46F25]" />
              </div>
              <h3 className="text-lg font-semibold">Expected Launch</h3>
            </div>
            <p className="text-[#E1E1E1] leading-relaxed">
              December 25, 2024
            </p>
          </div>

          {/* Vision Section */}
          <div className="border-t border-[#333333]/30 pt-8">
            <h2 className="text-2xl font-bold mb-4">Vision for this Page</h2>
            <p className="text-[#E1E1E1] leading-relaxed">
              Equip team members with quick, reliable access to crucial regulations, empowering informed 
              decision-making and adherence to industry standards.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}