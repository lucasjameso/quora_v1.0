import React from 'react';
import { ArrowLeft, Calendar, BookOpen, Users, Clock } from 'lucide-react';

interface ComplianceInsightsProps {
  onReturn: () => void;
}

export function ComplianceInsights({ onReturn }: ComplianceInsightsProps) {
  return (
    <div className="min-h-screen bg-[#1A1A1A] text-[#F4F5F1]">
      {/* Header with Return Button */}
      <div className="border-b border-[#333333]/30">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <button
            onClick={onReturn}
            className="flex items-center gap-2 text-[#F46F25] hover:text-[#FF8544] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Return to Home</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="space-y-12">
          {/* Header Section */}
          <div className="space-y-4">
            <h1 className="text-4xl font-bold text-[#F4F5F1]">Compliance Insights</h1>
            <div className="flex items-center gap-2 text-[#F46F25]">
              <Clock className="w-5 h-5" />
              <span className="text-lg">Coming Soon</span>
            </div>
          </div>

          {/* Main Description */}
          <div className="prose prose-invert max-w-none">
            <p className="text-xl text-[#E1E1E1] leading-relaxed">
              In-Depth Compliance Insights for Facade Access Solutions Team
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-6 rounded-xl bg-[#333333]/20 border border-[#333333]/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-[#F46F25]/10">
                  <Calendar className="w-5 h-5 text-[#F46F25]" />
                </div>
                <h3 className="text-lg font-semibold">Monthly Sessions</h3>
              </div>
              <p className="text-[#E1E1E1] leading-relaxed">
                Led by John Ho from Engineering, covering regulations, standards, and internal interpretations.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-[#333333]/20 border border-[#333333]/30">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 rounded-lg bg-[#F46F25]/10">
                  <BookOpen className="w-5 h-5 text-[#F46F25]" />
                </div>
                <h3 className="text-lg font-semibold">Resource Library</h3>
              </div>
              <p className="text-[#E1E1E1] leading-relaxed">
                Access past sessions and engineering insights, curated by our compliance expert.
              </p>
            </div>
          </div>

          {/* Launch Date */}
          <div className="bg-[#333333]/20 border border-[#333333]/30 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 rounded-lg bg-[#F46F25]/10">
                <Users className="w-5 h-5 text-[#F46F25]" />
              </div>
              <h3 className="text-lg font-semibold">Expected Launch</h3>
            </div>
            <p className="text-[#E1E1E1] leading-relaxed">
              December 25, 2024
            </p>
          </div>

          {/* Vision Section */}
          <div className="border-t border-[#333333]/30 pt-8">
            <h2 className="text-2xl font-bold mb-4">Vision for this Page</h2>
            <p className="text-[#E1E1E1] leading-relaxed">
              To provide structured, ongoing compliance education, strengthening the entire team's 
              understanding of regulatory intricacies in facade access.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}