import React from 'react';
import { format, isToday, isYesterday, isWithinInterval, subDays } from 'date-fns';
import { Archive, Clock, Edit2, MessageSquare, Share2, Trash2, Undo, ChevronLeft, Plus } from 'lucide-react';
import { useChatStore } from '../store/chatStore';
import { ChatThread } from '../types';
import { ThreadGroup } from './ThreadGroup';
import { ThreadItem } from './ThreadItem';

interface ChatThreadsProps {
  isCollapsed?: boolean;
}

export function ChatThreads({ isCollapsed = false }: ChatThreadsProps) {
  const { threads, createThread } = useChatStore();
  const [showArchived, setShowArchived] = React.useState(false);

  const groupThreads = (threads: ChatThread[]) => {
    const activeThreads = threads.filter(thread => !thread.isArchived);
    
    const groups = {
      today: activeThreads.filter(thread => isToday(new Date(thread.updatedAt))),
      yesterday: activeThreads.filter(thread => isYesterday(new Date(thread.updatedAt))),
      previousWeek: activeThreads.filter(thread => 
        isWithinInterval(new Date(thread.updatedAt), {
          start: subDays(new Date(), 7),
          end: subDays(new Date(), 2)
        })
      )
    };

    return groups;
  };

  const groupedThreads = groupThreads(threads);

  return (
    <div className="flex flex-col h-full">
      {!isCollapsed && (
        <>
          {groupedThreads.today.length > 0 && (
            <ThreadGroup title="Today" threads={groupedThreads.today} />
          )}
          {groupedThreads.yesterday.length > 0 && (
            <ThreadGroup title="Yesterday" threads={groupedThreads.yesterday} />
          )}
          {groupedThreads.previousWeek.length > 0 && (
            <ThreadGroup title="Previous 7 Days" threads={groupedThreads.previousWeek} />
          )}
        </>
      )}

      {isCollapsed && (
        <div className="py-4">
          {threads.map(thread => (
            <ThreadItem 
              key={thread.id}
              thread={thread}
              isCollapsed={true}
            />
          ))}
        </div>
      )}

      {threads.length === 0 && (
        <div className="p-4 text-center text-[#7F7F7F] text-sm">
          No conversations yet
        </div>
      )}

      {/* Footer */}
      {!isCollapsed && (
        <div className="p-4 border-t border-[#333333]/30">
          <button
            onClick={() => setShowArchived(!showArchived)}
            className="flex items-center gap-2 px-3 py-2 w-full rounded-lg hover:bg-[#333333]/30 transition-colors text-[#7F7F7F]"
          >
            {showArchived ? <Undo className="w-4 h-4" /> : <Archive className="w-4 h-4" />}
            <span>{showArchived ? 'Show Active' : 'Show Archived'}</span>
          </button>
        </div>
      )}
    </div>
  );
}