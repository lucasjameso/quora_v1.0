import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  FileText, 
  HelpCircle, 
  Users, 
  HeadphonesIcon, 
  BookOpenCheck,
  MessageSquarePlus,
  Menu
} from 'lucide-react';
import { ChatThreads } from './ChatThreads';
import { useChatStore } from '../store/chatStore';

type ViewType = 'home' | 'insights' | 'regulations' | 'standards' | 'how-it-works' | 'dashboard';

interface SidebarProps {
  onNavigate: (view: ViewType) => void;
  currentView: string;
}

export function Sidebar({ onNavigate, currentView }: SidebarProps) {
  const { createThread } = useChatStore();
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
    <aside className={`${isCollapsed ? 'w-16' : 'w-64'} bg-[#1A1A1A] flex flex-col h-full border-r border-[#333333]/30 transition-all duration-300 ease-in-out relative`}>
      {/* Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3 top-5 bg-[#1A1A1A] border border-[#333333]/30 rounded-full p-1.5 hover:bg-[#333333]/30 transition-colors z-50"
        aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        <Menu className={`w-4 h-4 text-[#7F7F7F] transition-transform duration-300 ${isCollapsed ? 'rotate-180' : ''}`} />
      </button>

      {/* Header */}
      <div className={`px-4 py-4 ${isCollapsed ? 'text-center' : ''}`}>
        <button 
          onClick={() => onNavigate('home')}
          className="text-[#F4F5F1] text-lg font-medium hover:text-[#F46F25] transition-colors"
        >
          {isCollapsed ? 'IH' : 'InnovateHub'}
        </button>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 flex flex-col">
        <div className="px-2 py-2 space-y-1">
          <button 
            onClick={() => onNavigate('insights')}
            className={`nav-item w-full ${currentView === 'insights' ? 'active' : ''}`}
          >
            <FileText className="w-5 h-5 text-[#7F7F7F]" />
            {!isCollapsed && <span>Compliance Insights</span>}
          </button>
          <button 
            onClick={() => onNavigate('regulations')}
            className={`nav-item w-full ${currentView === 'regulations' ? 'active' : ''}`}
          >
            <BookOpenCheck className="w-5 h-5 text-[#7F7F7F]" />
            {!isCollapsed && <span>Regulations Library</span>}
          </button>
          <button 
            onClick={() => onNavigate('standards')}
            className={`nav-item w-full ${currentView === 'standards' ? 'active' : ''}`}
          >
            <BookOpen className="w-5 h-5 text-[#7F7F7F]" />
            {!isCollapsed && <span>Standards Library</span>}
          </button>
          <button 
            onClick={() => onNavigate('how-it-works')}
            className={`nav-item w-full ${currentView === 'how-it-works' ? 'active' : ''}`}
          >
            <HelpCircle className="w-5 h-5 text-[#7F7F7F]" />
            {!isCollapsed && <span>How It Works</span>}
          </button>
        </div>

        {/* Gradient Separator */}
        <div className="h-px bg-gradient-to-r from-transparent via-[#333333]/50 to-transparent my-4" />

        {/* Chat Threads Section */}
        <div className="flex-1 overflow-hidden flex flex-col min-h-0">
          <div className="px-3 mb-2 flex items-center justify-between">
            {!isCollapsed && (
              <h2 className="text-xs font-semibold text-[#7F7F7F] uppercase tracking-wider">
                Conversations
              </h2>
            )}
            <button
              onClick={createThread}
              className="p-1 rounded hover:bg-[#333333]/30 text-[#7F7F7F] hover:text-[#F46F25] transition-colors"
              title="New conversation"
            >
              <MessageSquarePlus className="w-5 h-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto min-h-0">
            <ChatThreads isCollapsed={isCollapsed} />
          </div>
        </div>

        {/* Bottom Section with Support Links */}
        <div className="mt-auto">
          {/* Gradient Separator */}
          <div className="h-px bg-gradient-to-r from-transparent via-[#333333]/30 to-transparent mb-4" />
          
          <div className="px-2 pb-4">
            <div className="space-y-1">
              <button className="nav-item w-full">
                <HeadphonesIcon className="w-5 h-5 text-[#7F7F7F]" />
                {!isCollapsed && <span>Contact Support</span>}
              </button>
              <button className="nav-item w-full">
                <Users className="w-5 h-5 text-[#7F7F7F]" />
                {!isCollapsed && <span>Invite Team</span>}
              </button>
              <button 
                onClick={() => onNavigate('dashboard')}
                className={`nav-item w-full ${currentView === 'dashboard' ? 'active' : ''}`}
              >
                <LayoutDashboard className="w-5 h-5 text-[#7F7F7F]" />
                {!isCollapsed && <span>Dashboard</span>}
              </button>
            </div>
          </div>
        </div>
      </nav>
    </aside>
  );
}