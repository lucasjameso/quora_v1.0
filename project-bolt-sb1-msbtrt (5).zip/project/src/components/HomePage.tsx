import React, { useState, useRef, useEffect } from 'react';
import { QueryType } from '../types';
import { ChatInput } from './ChatInput';
import { MessageList } from './MessageList';
import { EnhancedPrompts } from './EnhancedPrompts';
import { Message } from '../types';

interface HomePageProps {
  onStartAnalysis: (type: QueryType) => void;
  onSearch: (query: string, file?: File) => void;
}

export function HomePage({ onStartAnalysis, onSearch }: HomePageProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showEnhancedPrompts, setShowEnhancedPrompts] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSearch = async (query: string, file?: File) => {
    if (!query.trim() && !file) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: query,
      sender: 'user',
      timestamp: new Date(),
      attachment: file
    };

    setMessages(prev => [...prev, userMessage]);
    setIsProcessing(true);

    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Based on your query, here's what I found in our compliance database...\n\n" +
                "The regulations specify several key requirements:\n\n" +
                "1. Regular compliance audits\n" +
                "2. Documentation maintenance\n" +
                "3. Staff training programs\n\n" +
                "Would you like me to elaborate on any of these points?",
        sender: 'bot',
        timestamp: new Date(),
        sources: [
          {
            id: '1',
            title: 'Compliance Guidelines 2024',
            content: 'Detailed compliance requirements and implementation guidelines.'
          }
        ]
      };

      setMessages(prev => [...prev, botMessage]);
      setIsProcessing(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-screen max-h-screen bg-[#2A2A2A] relative">
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-[#2A2A2A] via-[#2A2A2A]/95 to-[#2A2A2A]" />
      </div>

      {/* Main Content */}
      <main className="relative flex-1 flex flex-col w-full max-w-4xl mx-auto px-4 sm:px-6 overflow-hidden">
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="text-center space-y-6 mb-32">
              <h1 className="text-4xl sm:text-5xl font-bold text-[#F4F5F1]">
                Compliance Assistant
              </h1>
              <p className="text-lg sm:text-xl text-[#F4F5F1] max-w-2xl mx-auto px-4">
                Discover insights on standards and regulations or upload files for compliance analysis.
              </p>
            </div>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto py-4 sm:py-6 scrollbar-thin">
            <MessageList messages={messages} onSourceClick={() => {}} />
            <div ref={messagesEndRef} />
          </div>
        )}

        {/* Fixed Bottom Section */}
        <div className="sticky bottom-0 left-0 right-0 z-10 w-full">
          <EnhancedPrompts
            isVisible={showEnhancedPrompts}
            onSelect={(prompt) => {
              handleSearch(prompt);
              setShowEnhancedPrompts(false);
            }}
          />

          <div className="bg-gradient-to-t from-[#2A2A2A] to-transparent pt-6 pb-4 sm:pt-8 sm:pb-6">
            <ChatInput 
              onSend={handleSearch}
              isProcessing={isProcessing}
              onEnhancePrompt={() => setShowEnhancedPrompts(!showEnhancedPrompts)}
              showEnhancedPrompts={showEnhancedPrompts}
            />
          </div>
        </div>
      </main>
    </div>
  );
}