import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer
} from 'recharts';
import {
  Users,
  MessageSquare,
  Clock,
  FileText,
  TrendingUp,
  Activity,
  Star,
  BookOpen,
  Search,
  Download,
  ThumbsUp,
  ArrowLeft
} from 'lucide-react';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

interface DashboardProps {
  onReturn: () => void;
}

export function Dashboard({ onReturn }: DashboardProps) {
  // Sample data - replace with real data in production
  const userEngagementData = [
    { name: 'Mon', queries: 120, enhancedPrompts: 45, fileAttachments: 25 },
    { name: 'Tue', queries: 150, enhancedPrompts: 55, fileAttachments: 30 },
    { name: 'Wed', queries: 180, enhancedPrompts: 65, fileAttachments: 35 },
    { name: 'Thu', queries: 160, enhancedPrompts: 60, fileAttachments: 28 },
    { name: 'Fri', queries: 140, enhancedPrompts: 50, fileAttachments: 22 }
  ];

  const complianceSessionData = [
    { name: 'Safety Standards', value: 400 },
    { name: 'Regulatory Updates', value: 300 },
    { name: 'Best Practices', value: 300 },
    { name: 'Technical Guidelines', value: 200 }
  ];

  const performanceData = [
    { name: '9AM', responseTime: 250 },
    { name: '10AM', responseTime: 200 },
    { name: '11AM', responseTime: 180 },
    { name: '12PM', responseTime: 220 },
    { name: '1PM', responseTime: 270 },
    { name: '2PM', responseTime: 250 }
  ];

  return (
    <div className="bg-[#1A1A1A] min-h-screen">
      {/* Header with Return Button */}
      <div className="border-b border-[#333333]/30">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <button
            onClick={onReturn}
            className="flex items-center gap-2 text-[#F46F25] hover:text-[#FF8544] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Return to Home</span>
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8 space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-[#F4F5F1] mb-2">Dashboard Overview</h1>
          <p className="text-[#7F7F7F]">Monitor your compliance insights and system performance</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <QuickStat
            icon={<MessageSquare className="w-6 h-6" />}
            title="Total Queries"
            value="1,234"
            change="+12.5%"
            color="text-blue-500"
          />
          <QuickStat
            icon={<Users className="w-6 h-6" />}
            title="Active Users"
            value="456"
            change="+8.3%"
            color="text-green-500"
          />
          <QuickStat
            icon={<Clock className="w-6 h-6" />}
            title="Avg. Response Time"
            value="1.2s"
            change="-15.2%"
            color="text-purple-500"
          />
          <QuickStat
            icon={<Star className="w-6 h-6" />}
            title="User Satisfaction"
            value="4.8/5"
            change="+0.3"
            color="text-yellow-500"
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
          {/* User Engagement Chart */}
          <div className="bg-[#2A2A2A] p-6 rounded-xl border border-[#333333]/30">
            <h2 className="text-lg font-semibold text-[#F4F5F1] mb-4">User Engagement</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={userEngagementData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
                  <XAxis dataKey="name" stroke="#7F7F7F" />
                  <YAxis stroke="#7F7F7F" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#2A2A2A',
                      border: '1px solid #333333',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Bar dataKey="queries" fill="#0088FE" name="Queries" />
                  <Bar dataKey="enhancedPrompts" fill="#00C49F" name="Enhanced Prompts" />
                  <Bar dataKey="fileAttachments" fill="#FFBB28" name="File Attachments" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Compliance Topics Distribution */}
          <div className="bg-[#2A2A2A] p-6 rounded-xl border border-[#333333]/30">
            <h2 className="text-lg font-semibold text-[#F4F5F1] mb-4">Compliance Topics Distribution</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={complianceSessionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {complianceSessionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* System Performance */}
          <div className="bg-[#2A2A2A] p-6 rounded-xl border border-[#333333]/30">
            <h2 className="text-lg font-semibold text-[#F4F5F1] mb-4">System Performance</h2>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333333" />
                  <XAxis dataKey="name" stroke="#7F7F7F" />
                  <YAxis stroke="#7F7F7F" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#2A2A2A',
                      border: '1px solid #333333',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="responseTime"
                    stroke="#8884d8"
                    name="Response Time (ms)"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-[#2A2A2A] p-6 rounded-xl border border-[#333333]/30">
            <h2 className="text-lg font-semibold text-[#F4F5F1] mb-4">Recent Activity</h2>
            <div className="space-y-4">
              <ActivityItem
                icon={<Search className="w-4 h-4" />}
                title="New Search Query"
                description="Safety standards for window washing systems"
                time="5 minutes ago"
              />
              <ActivityItem
                icon={<Download className="w-4 h-4" />}
                title="Document Download"
                description="OSHA Guidelines 2024"
                time="15 minutes ago"
              />
              <ActivityItem
                icon={<BookOpen className="w-4 h-4" />}
                title="Session Attendance"
                description="Monthly Compliance Update"
                time="1 hour ago"
              />
              <ActivityItem
                icon={<ThumbsUp className="w-4 h-4" />}
                title="Positive Feedback"
                description="Response quality rated 5/5"
                time="2 hours ago"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function QuickStat({ icon, title, value, change, color }: {
  icon: React.ReactNode;
  title: string;
  value: string;
  change: string;
  color: string;
}) {
  return (
    <div className="bg-[#2A2A2A] p-6 rounded-xl border border-[#333333]/30">
      <div className="flex items-center gap-4">
        <div className={`p-3 rounded-lg ${color} bg-opacity-10`}>
          {React.cloneElement(icon as React.ReactElement, {
            className: `w-6 h-6 ${color}`
          })}
        </div>
        <div>
          <p className="text-sm text-[#7F7F7F]">{title}</p>
          <div className="flex items-center gap-2">
            <p className="text-2xl font-semibold text-[#F4F5F1]">{value}</p>
            <span className={`text-sm ${
              change.startsWith('+') ? 'text-green-500' : 'text-red-500'
            }`}>
              {change}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

function ActivityItem({ icon, title, description, time }: {
  icon: React.ReactNode;
  title: string;
  description: string;
  time: string;
}) {
  return (
    <div className="flex items-center gap-4 p-3 rounded-lg bg-[#333333]/20">
      <div className="p-2 rounded-lg bg-[#333333]/30">
        {React.cloneElement(icon as React.ReactElement, {
          className: 'w-4 h-4 text-[#F46F25]'
        })}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-[#F4F5F1]">{title}</p>
        <p className="text-xs text-[#7F7F7F] truncate">{description}</p>
      </div>
      <span className="text-xs text-[#7F7F7F]">{time}</span>
    </div>
  );
}