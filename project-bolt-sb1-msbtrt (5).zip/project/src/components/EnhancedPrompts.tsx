import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';

interface EnhancedPromptsProps {
  isVisible: boolean;
  onSelect: (prompt: string) => void;
}

export function EnhancedPrompts({ isVisible, onSelect }: EnhancedPromptsProps) {
  if (!isVisible) return null;

  const suggestions = [
    "What is the minimum height requirement for toeboards on elevated platforms in California?",
    "How much clearance is allowed under toeboards on elevated platforms according to California regulations?",
    "Can you explain why California regulations specify a minimum height and clearance for toeboards?",
    "Which documents outline the height and clearance standards for toeboards on elevated work platforms?",
    "What safety purpose does the 1/4-inch clearance limit serve for toeboards on platforms over 50 feet?"
  ];

  return (
    <div className="mb-4">
      <div className="bg-[#333333]/30 rounded-xl p-4 backdrop-blur-sm border border-[#333333]/30">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-[#F46F25]" />
          <span className="text-sm font-medium text-[#F4F5F1]">Enhanced Prompts</span>
        </div>
        <div className="space-y-2">
          {suggestions.map((suggestion, index) => (
            <button
              key={index}
              onClick={() => onSelect(suggestion)}
              className="w-full flex items-center justify-between p-3 rounded-lg
                       bg-[#333333]/20 hover:bg-[#333333]/30
                       text-left text-[#F4F5F1] transition-colors group"
            >
              <span className="pr-4">{suggestion}</span>
              <ArrowRight className="w-4 h-4 text-[#F46F25] opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}