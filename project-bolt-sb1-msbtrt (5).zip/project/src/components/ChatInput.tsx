import React, { useState, KeyboardEvent } from 'react';
import { Send, Loader2, Paperclip, Sparkles } from 'lucide-react';
import { FileUpload } from './FileUpload';

interface ChatInputProps {
  onSend: (message: string, file?: File) => void;
  isProcessing: boolean;
  onEnhancePrompt: () => void;
  showEnhancedPrompts: boolean;
  placeholder?: string;
}

export function ChatInput({ 
  onSend, 
  isProcessing, 
  onEnhancePrompt,
  showEnhancedPrompts,
  placeholder = "Message ComplianceGPT..." 
}: ChatInputProps) {
  const [input, setInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File>();

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if ((input.trim() || selectedFile) && !isProcessing) {
      onSend(input.trim(), selectedFile);
      setInput('');
      setSelectedFile(undefined);
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form onSubmit={handleSubmit} className="relative">
        <div className="relative flex flex-col gap-2">
          <div className="relative flex items-end bg-[#333333]/30 rounded-xl shadow-lg border border-[#333333]/50">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={placeholder}
              rows={1}
              className="w-full resize-none bg-transparent px-4 py-4 pr-20
                       text-[#F4F5F1] placeholder-[#7F7F7F]
                       focus:outline-none focus:ring-0
                       max-h-[200px] overflow-y-auto"
              style={{
                minHeight: '24px',
                height: 'auto'
              }}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = `${Math.min(target.scrollHeight, 200)}px`;
              }}
            />

            <div className="absolute right-2 bottom-2 flex items-center gap-2">
              <button
                type="button"
                onClick={onEnhancePrompt}
                className={`p-2 rounded-lg transition-colors ${
                  showEnhancedPrompts 
                    ? 'text-[#F46F25] bg-[#F46F25]/10' 
                    : 'text-[#7F7F7F] hover:text-[#F46F25] hover:bg-[#F46F25]/5'
                }`}
                title="Enhanced Prompts"
              >
                <Sparkles className="w-4 h-4" />
              </button>

              <FileUpload
                onFileSelect={(file) => setSelectedFile(file)}
                selectedFile={selectedFile}
                onClear={() => setSelectedFile(undefined)}
              />

              <button
                type="submit"
                disabled={isProcessing || (!input.trim() && !selectedFile)}
                className="p-2 rounded-lg text-[#F46F25] hover:bg-[#F46F25]/5 
                         disabled:opacity-40 disabled:hover:bg-transparent
                         transition-all duration-200"
              >
                {isProcessing ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>

          <div className="px-2 flex justify-center">
            <div className="text-xs text-[#7F7F7F] flex items-center gap-1">
              <kbd className="px-1.5 py-0.5 font-mono bg-[#333333]/50 rounded border border-[#404040]">Enter</kbd>
              to send,
              <kbd className="px-1.5 py-0.5 font-mono bg-[#333333]/50 rounded border border-[#404040]">Shift + Enter</kbd>
              for new line
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}