import React from 'react';
import { FileText } from 'lucide-react';
import { Message, Source } from '../types';

interface MessageListProps {
  messages: Message[];
  onSourceClick: (source: Source) => void;
}

export function MessageList({ messages, onSourceClick }: MessageListProps) {
  return (
    <div className="w-full max-w-3xl mx-auto">
      {messages.map((message) => (
        <div
          key={message.id}
          className={`py-8 first:pt-12 ${
            message.sender === 'user' 
              ? 'border-t border-[#333333]/10' 
              : ''
          }`}
        >
          <div className="max-w-3xl mx-auto px-4">
            <div className="flex gap-4 items-start">
              {/* Avatar */}
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                message.sender === 'user' 
                  ? 'bg-[#F46F25]' 
                  : 'bg-gradient-to-br from-[#F46F25] to-[#FF8544]'
              }`}>
                <span className="text-white text-sm font-medium">
                  {message.sender === 'user' ? 'Y' : 'A'}
                </span>
              </div>

              {/* Message Content */}
              <div className="flex-1">
                {message.attachment && (
                  <div className="inline-flex items-center gap-2 px-3 py-2 mb-3 rounded-lg bg-[#333333]/20 text-sm text-[#F4F5F1]">
                    <FileText className="w-4 h-4 text-[#F46F25]" />
                    <span>{message.attachment.name}</span>
                  </div>
                )}

                <div className={`prose prose-invert max-w-none ${
                  message.sender === 'user' 
                    ? 'text-lg font-medium' 
                    : ''
                }`}>
                  <p className={`whitespace-pre-wrap leading-7 ${
                    message.sender === 'user'
                      ? 'text-[#F4F5F1]'
                      : 'text-[#E1E1E1]'
                  }`}>
                    {message.content}
                  </p>
                </div>

                {message.sources && message.sources.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {message.sources.map((source) => (
                      <button
                        key={source.id}
                        onClick={() => onSourceClick(source)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 
                                 text-[#F46F25] hover:bg-[#F46F25]/10 
                                 rounded-lg transition-colors text-sm group"
                      >
                        <FileText className="w-4 h-4" />
                        <span>View Source</span>
                      </button>
                    ))}
                  </div>
                )}

                {/* Timestamp */}
                <div className="text-xs text-[#7F7F7F] mt-3">
                  {new Date(message.timestamp).toLocaleTimeString([], { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}