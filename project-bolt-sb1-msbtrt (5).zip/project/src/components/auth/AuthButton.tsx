import React from 'react';
import { LogIn } from 'lucide-react';

interface AuthButtonProps {
  onSignInClick: () => void;
}

export function AuthButton({ onSignInClick }: AuthButtonProps) {
  return (
    <button
      onClick={onSignInClick}
      className="flex items-center gap-2 px-4 py-2 rounded-lg bg-brand-accent hover:bg-brand-accent/90 text-white transition-all duration-200 shadow-lg"
    >
      <LogIn className="w-4 h-4" />
      <span>Sign In</span>
    </button>
  );
}