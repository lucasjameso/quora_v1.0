export interface ChatThread {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
  isArchived: boolean;
  isEditing?: boolean;
}

export interface ChatStore {
  threads: ChatThread[];
  activeThreadId: string | null;
  hasInitiatedFirstQuery: boolean;
  setActiveThread: (threadId: string) => void;
  createThread: () => void;
  initiateFirstQuery: () => void;
  updateThread: (threadId: string, updates: Partial<ChatThread>) => void;
  deleteThread: (threadId: string) => void;
  archiveThread: (threadId: string) => void;
  restoreThread: (threadId: string) => void;
  addMessage: (threadId: string, message: Message) => void;
}

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  attachment?: File;
  sources?: Source[];
}

export interface Source {
  id: string;
  title: string;
  content: string;
  type?: string;
  jurisdiction?: string;
  category?: string;
  lastUpdated?: Date;
  filename?: string;
}

export type QueryType = 'regulatory_analysis' | 'compliance_check' | 'standard_interpretation';