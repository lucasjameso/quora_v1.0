import React, { useState } from 'react';
import { ChatInput } from './components/ChatInput';
import { MessageList } from './components/MessageList';
import { SourcePanel } from './components/SourcePanel';
import { Sidebar } from './components/Sidebar';
import { AuthButton } from './components/auth/AuthButton';
import { AuthModal } from './components/auth/AuthModal';
import { Message, Source } from './types';
import { useChatStore } from './store/chatStore';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import { EnhancedPrompts } from './components/EnhancedPrompts';
import { ComplianceInsights } from './components/ComplianceInsights';
import { RegulationsLibrary } from './components/RegulationsLibrary';
import { StandardsLibrary } from './components/StandardsLibrary';
import { HowItWorks } from './components/HowItWorks';
import { Dashboard } from './components/Dashboard';

type ViewType = 'home' | 'insights' | 'regulations' | 'standards' | 'how-it-works' | 'dashboard';

export function App() {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [sourcePanelOpen, setSourcePanelOpen] = useState(false);
  const [selectedSource, setSelectedSource] = useState<Source>();
  const [showEnhancedPrompts, setShowEnhancedPrompts] = useState(false);
  const [currentView, setCurrentView] = useState<ViewType>('home');
  
  const { threads, activeThreadId, addMessage, createThread, initiateFirstQuery } = useChatStore();
  useKeyboardShortcuts();

  React.useEffect(() => {
    if (threads.length === 0) {
      createThread();
    }
    initiateFirstQuery();

  }, []);

  const activeThread = threads.find(thread => thread.id === activeThreadId);
  const messages = activeThread?.messages || [];

  const handleSearch = async (query: string, file?: File) => {
    if (!activeThreadId) return;
    if (!query.trim() && !file) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: query,
      sender: 'user',
      timestamp: new Date(),
      attachment: file
    };

    addMessage(activeThreadId, userMessage);
    setShowEnhancedPrompts(false);

    // Simulate bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Based on the California Code of Regulations, Title 8, Section 3214, here are the key requirements for stair rails and handrails:\n\n" +
                "1. Regular compliance audits must be conducted\n" +
                "2. Documentation must be maintained\n" +
                "3. Staff training programs are required\n\n" +
                "Would you like me to elaborate on any of these points or show you the full regulation text?",
        sender: 'bot',
        timestamp: new Date(),
        sources: [
          {
            id: '1',
            title: 'California Code of Regulations, Title 8, Section 3214',
            content: 'Stair Rails and Handrails requirements and specifications.',
            type: 'regulation',
            jurisdiction: 'California',
            category: 'Occupational Safety',
            lastUpdated: new Date('2024-01-03')
          }
        ]
      };

      addMessage(activeThreadId, botMessage);
    }, 1000);
  };

  const handleNavigate = (view: ViewType) => {
    setCurrentView(view);
  };

  if (currentView === 'insights') {
    return <ComplianceInsights onReturn={() => setCurrentView('home')} />;
  }

  if (currentView === 'regulations') {
    return <RegulationsLibrary onReturn={() => setCurrentView('home')} />;
  }

  if (currentView === 'standards') {
    return <StandardsLibrary onReturn={() => setCurrentView('home')} />;
  }

  if (currentView === 'how-it-works') {
    return <HowItWorks onReturn={() => setCurrentView('home')} />;
  }

  if (currentView === 'dashboard') {
    return <Dashboard onReturn={() => setCurrentView('home')} />;
  }

  return (
    <div className="flex h-screen bg-[#1A1A1A]">
      <Sidebar 
        onNavigate={handleNavigate}
        currentView={currentView}
      />
      
      <main className="flex-1 flex flex-col relative">
        <div className="absolute top-4 right-4 z-10">
          <AuthButton onSignInClick={() => setShowAuthModal(true)} />
        </div>

        <div className="flex-1 overflow-hidden flex flex-col">
          <div className="flex-1 overflow-y-auto scrollbar-thin">
            {messages.length === 0 ? (
              <div className="h-full flex items-center justify-center">
                <div className="text-center space-y-6 max-w-2xl w-full px-4">
                  <h1 className="text-4xl font-bold text-[#F4F5F1]">
                    Compliance Assistant
                  </h1>
                  <p className="text-lg text-[#BFBFBF]">
                    Discover insights on standards and regulations or upload files for compliance analysis.
                  </p>
                </div>
              </div>
            ) : (
              <MessageList
                messages={messages}
                onSourceClick={(source) => {
                  setSelectedSource(source);
                  setSourcePanelOpen(true);
                }}
              />
            )}
          </div>

          <div className="border-t border-[#333333]/30 bg-gradient-to-t from-[#1A1A1A] to-transparent">
            <div className="max-w-3xl mx-auto px-4 py-4">
              {showEnhancedPrompts && (
                <EnhancedPrompts
                  isVisible={showEnhancedPrompts}
                  onSelect={(prompt) => {
                    handleSearch(prompt);
                    setShowEnhancedPrompts(false);
                  }}
                />
              )}
              
              <ChatInput 
                onSend={handleSearch}
                isProcessing={false}
                onEnhancePrompt={() => setShowEnhancedPrompts(!showEnhancedPrompts)}
                showEnhancedPrompts={showEnhancedPrompts}
              />
              
              <div className="mt-4 text-center">
                <p className="text-xs text-[#7F7F7F] px-4">
                  Note: InnovateHub offers reference information on compliance topics. This tool may make mistakes, so consult official sources to confirm interpretations.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <SourcePanel
        source={selectedSource}
        isOpen={sourcePanelOpen}
        onClose={() => setSourcePanelOpen(false)}
      />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
      />
    </div>
  );
}