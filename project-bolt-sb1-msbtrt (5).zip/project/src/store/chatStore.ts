import { create } from 'zustand';
import { ChatStore, ChatThread, Message } from '../types';

let nextId = 1;
const generateId = () => `thread-${nextId++}`;

export const useChatStore = create<ChatStore>((set, get) => ({
  threads: [],
  activeThreadId: null,
  hasInitiatedFirstQuery: false,

  setActiveThread: (threadId) => {
    set({ activeThreadId: threadId });
  },

  createThread: () => {
    const { threads } = get();
    
    // Only create a new thread if there isn't an empty one
    const emptyThread = threads.find(thread => thread.messages.length === 0);
    if (emptyThread) {
      set({ activeThreadId: emptyThread.id });
      return emptyThread.id;
    }

    const newThread: ChatThread = {
      id: generateId(),
      title: 'New Conversation',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
      isArchived: false
    };

    set((state) => ({
      threads: [newThread, ...state.threads],
      activeThreadId: newThread.id
    }));

    return newThread.id;
  },

  initiateFirstQuery: () => {
    const { threads } = get();
    if (threads.length === 0) {
      const threadId = get().createThread();
      set({ hasInitiatedFirstQuery: true });
    }
  },

  updateThread: (threadId, updates) => {
    set((state) => ({
      threads: state.threads.map((thread) =>
        thread.id === threadId ? { ...thread, ...updates } : thread
      )
    }));
  },

  deleteThread: (threadId) => {
    set((state) => {
      const newThreads = state.threads.filter((thread) => thread.id !== threadId);
      const newState = {
        threads: newThreads,
        activeThreadId: state.activeThreadId === threadId ? null : state.activeThreadId
      };

      if (newState.activeThreadId === null && newThreads.length > 0) {
        newState.activeThreadId = newThreads[0].id;
      }

      return newState;
    });
  },

  archiveThread: (threadId) => {
    set((state) => ({
      threads: state.threads.map((thread) =>
        thread.id === threadId ? { ...thread, isArchived: true } : thread
      )
    }));
  },

  restoreThread: (threadId) => {
    set((state) => ({
      threads: state.threads.map((thread) =>
        thread.id === threadId ? { ...thread, isArchived: false } : thread
      )
    }));
  },

  addMessage: (threadId, message) => {
    const messageWithId = {
      ...message,
      id: `msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    };

    set((state) => ({
      threads: state.threads.map((thread) =>
        thread.id === threadId
          ? {
              ...thread,
              messages: [...thread.messages, messageWithId],
              updatedAt: new Date(),
              title: thread.messages.length === 0 ? message.content.slice(0, 30) + '...' : thread.title,
              hasInitiatedFirstQuery: true
            }
          : thread
      )
    }));
  }
}));